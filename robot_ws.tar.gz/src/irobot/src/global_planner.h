/** include the libraries you need in your planner here */
/** for global path planner interface */
//需要包含路径规划器所需的核心ROS库
#include <angles/angles.h>
#include <base_local_planner/costmap_model.h>
#include <base_local_planner/world_model.h>
#include <costmap_2d/costmap_2d.h>      //路径规划器需要使用
#include <costmap_2d/costmap_2d_ros.h>  //路径规划器需要使用
#include <geometry_msgs/PoseStamped.h>
#include <nav_core/base_global_planner.h>  //导入接口nav_core::BaseGlobalPlanner插件必须要继承的父类
#include <ros/ros.h>

using std::string;

#ifndef GLOBAL_PLANNER_CPP
#define GLOBAL_PLANNER_CPP

//定义命名空间：将为GlobalPlanner类定义命名空间为global_planner
namespace global_planner {
//定义类GlobalPlanner并继承接口nav_core::BaseGlobalPlanner
class GlobalPlanner : public nav_core::BaseGlobalPlanner {
 public:
  GlobalPlanner();  //默认构造函数GlobalPlanner()即使用默认值作为初始化
  GlobalPlanner(std::string name,
                costmap_2d::Costmap2DROS* costmap_ros);  //初始化代价地图

  /** overridden classes from interface nav_core::BaseGlobalPlanner **/
  void initialize(
      std::string name,
      costmap_2d::Costmap2DROS*
          costmap_ros);  // BaseGlobalPlanner的初始化函数，用于初始化costmap
  bool makePlan(const geometry_msgs::PoseStamped& start,
                const geometry_msgs::PoseStamped& goal,
                std::vector<geometry_msgs::PoseStamped>& plan);  //最终规划将存储在方法的参数std::vector<geometry_msgs::PoseStamped>&
                                                                 //plan 中
};
};  // namespace global_planner
#endif