#include <apf_star_global_planner/apf_star_ros.h>
#include <pluginlib/class_list_macros.h>
#include <tf/tf.h>

#include <iostream>

PLUGINLIB_EXPORT_CLASS(APFstar_planner::APFstarPlannerROS,
                       nav_core::BaseGlobalPlanner)

namespace APFstar_planner {

APFstarPlannerROS::APFstarPlannerROS()
    : costmap_(nullptr), initialized_(false) {}

APFstarPlannerROS::APFstarPlannerROS(std::string name,
                                     costmap_2d::Costmap2DROS* costmap_ros)
    : costmap_ros_(costmap_ros), initialized_(false) {
  initialize(name, costmap_ros);
}

APFstarPlannerROS::~APFstarPlannerROS() {}

//变量初始化
void APFstarPlannerROS::initialize(std::string name,
                                   costmap_2d::Costmap2DROS* costmap_ros) {
  if (!initialized_) {
    // Initialize map
    costmap_ros_ = costmap_ros;
    costmap_ = costmap_ros->getCostmap();
    frame_id_ = costmap_ros->getGlobalFrameID();

    ros::NodeHandle private_nh("~/" + name);
    plan_pub_ = private_nh.advertise<nav_msgs::Path>("plan", 1);  //发布全局计算
    marker_pub_ = private_nh.advertise<visualization_msgs::Marker>(
        "visualization_marker", 0);  //发布可视化扩展过程

    resolution_ = costmap_->getResolution();  //地图分辨率

    double max_nodes_num_tem = 0.0;

    private_nh.param("search_radius", search_radius_,
                     1.0);  //搜索附近的节点的搜索范围
    private_nh.param("goal_radius", goal_radius_,
                     0.2);  //认为搜索到目标点的范围
    private_nh.param("epsilon_min", epsilon_min_,
                     0.001);  //节点之间的最小允许距离
    private_nh.param("epsilon_max", epsilon_max_,
                     0.1);  //节点之间的最大允许距离
    private_nh.param("max_nodes_num", max_nodes_num_tem,
                     2000000000.0);  //节点数的最大值，最大迭代次数
    private_nh.param("plan_time_out", plan_time_out_,
                     10.0);  //规划超时。默认10s
    max_nodes_num_ = static_cast<size_t>(max_nodes_num_tem);

    //路径优化参数
    path_point_spacing_ = 0.025;    //路径点间隔
    angle_difference_ = M_PI / 20;  //前后相邻点向量角度差

    ROS_WARN("APF* planner initialized successfully");
    initialized_ = true;
  } else {
    ROS_WARN("This planner has already been initialized... doing nothing");
  }
}

//标准化角度
double APFstarPlannerROS::normalizeAngle(double val, double min,
                                         double max)  //标准化角度
{
  double norm = 0.0;
  if (val >= min)
    norm = min + fmod((val - min), (max - min));
  else
    norm = max - fmod((min - val), (max - min));

  return norm;
}

//路径可视化
void APFstarPlannerROS::pubTreeMarker(ros::Publisher& marker_pub,
                                      visualization_msgs::Marker marker,
                                      int id) {
  marker.header.frame_id = "map";
  marker.header.stamp = ros::Time::now();
  marker.ns = "marker_namespace";
  marker.id = id;
  // marker.type = visualization_msgs::Marker::SPHERE;
  marker.type = visualization_msgs::Marker::LINE_LIST;
  marker.action = visualization_msgs::Marker::ADD;
  marker.pose.position.x = 0;
  marker.pose.position.y = 0;
  marker.pose.position.z = 0;
  marker.pose.orientation.x = 0.0;
  marker.pose.orientation.y = 0.0;
  marker.pose.orientation.z = 0.0;
  marker.pose.orientation.w = 1.0;
  marker.scale.x = 0.01;
  //         marker.scale.y = 0.1;
  //         marker.scale.z = 0.1;
  marker.color.a = 1.0;  // Don't forget to set the alpha!
  marker.color.r = 1.0;
  marker.color.g = 0.0;
  marker.color.b = 0.0;
  marker.lifetime = ros::Duration();
  marker.frame_locked = false;

  marker_pub.publish(marker);
}

//路径规划，最终move_base调用的函数
bool APFstarPlannerROS::makePlan(
    const geometry_msgs::PoseStamped& start,
    const geometry_msgs::PoseStamped& goal,
    std::vector<geometry_msgs::PoseStamped>& plan) {
  plan.clear();

  if (this->collision(start.pose.position.x, start.pose.position.y)) {
    ROS_WARN("failed to get a path.start point is obstacle.");
    return false;
  }

  if (this->collision(goal.pose.position.x, goal.pose.position.y)) {
    ROS_WARN("failed to get a path.goal point is obstacle.");
    return false;
  }

  this->marker_tree_.points.clear();
  this->marker_tree_2_.points.clear();
  plan.clear();
  std::vector<std::pair<double, double> > path;

  std::vector<Node> nodes;  //第一棵树
  Node start_node;
  start_node.x = start.pose.position.x;
  start_node.y = start.pose.position.y;
  start_node.node_id = 0;
  start_node.parent_id = -1;  // None parent node
  start_node.cost = 0.0;
  nodes.push_back(start_node);

  std::vector<Node> nodes_2;  //第二棵树
  Node goal_node;
  goal_node.x = goal.pose.position.x;
  goal_node.y = goal.pose.position.y;
  goal_node.node_id = 0;
  goal_node.parent_id = -1;  // None parent node
  goal_node.cost = 0.0;
  nodes_2.push_back(goal_node);

  std::pair<double, double> p_rand;   //随机采样的可行点
  std::pair<double, double> p_new;    //第一棵树的新节点
  std::pair<double, double> p_new_2;  //第二棵树的新节点
  Node
      connect_node_on_tree1;  //第二课树与第一课树连接到一起时第一课树上距离第二课树最近的节点
  Node
      connect_node_on_tree2;  //第一课树与第二课树连接到一起时第二课树上距离第二课树最近的节点
  bool is_connect_to_tree1 = false;
  bool is_connect_to_tree2 = false;

  Node node_nearest;

  unsigned int seed = 0;
  double start_time = ros::Time::now().toSec();
  while (ros::ok() && nodes.size() + nodes_2.size() < max_nodes_num_) {
    if ((ros::Time::now().toSec() - start_time) > plan_time_out_) {
      ROS_WARN("failed to get a path.time out.");
      return false;
    }
    // 第一棵树
    while (ros::ok()) {
      srand(ros::Time::now().toNSec() + seed++);  //修改种子
      unsigned int rand_nu = rand() % 10;
      if (rand_nu > 1)  // 0.8的概率使用随机采样扩展
      {
        p_rand = sampleFree();  // random point in the free space
      } else                    // 0.2的概率使用启发扩展
      {
        p_rand.first = goal.pose.position.x;
        p_rand.second = goal.pose.position.y;
      }

      node_nearest =
          getNearest(nodes, p_rand);  // The nearest node of the random point
      p_new = steer(node_nearest.x, node_nearest.y, p_rand.first,
                    p_rand.second);  // new point and node candidate.
      if (obstacleFree(node_nearest, p_new.first, p_new.second)) {  //树枝无碰撞
        Node newnode;
        newnode.x = p_new.first;
        newnode.y = p_new.second;
        newnode.node_id =
            nodes
                .size();  // index of the last element after the push_bask below
        newnode.parent_id = node_nearest.node_id;
        newnode.cost = 0.0;

        // 优化
        newnode = chooseParent(node_nearest, newnode,
                               nodes);  // Select the best parent
        nodes.push_back(newnode);
        rewire(nodes, newnode);

        geometry_msgs::Point point_tem;
        point_tem.x = nodes[newnode.parent_id].x;
        point_tem.y = nodes[newnode.parent_id].y;
        point_tem.z = 0;
        this->marker_tree_.points.push_back(point_tem);

        point_tem.x = newnode.x;
        point_tem.y = newnode.y;
        point_tem.z = 0;
        this->marker_tree_.points.push_back(point_tem);

        if (nodes.size() % 10 == 0) {
          this->pubTreeMarker(this->marker_pub_, this->marker_tree_, 1);
        }

        if (this->isConnect(newnode, nodes_2, nodes, connect_node_on_tree2)) {
          is_connect_to_tree2 = true;
        }

        break;
      }
    }

    //两棵树连接在了一起,第一棵树搜索到了第二棵树上的节点
    if (is_connect_to_tree2) {
      std::cout << "两棵树连接在了一起 1->2 耗时："
                << ros::Time::now().toSec() - start_time << "秒" << std::endl;

      getPathFromTree(nodes, nodes_2, connect_node_on_tree2, plan,
                      GetPlanMode::CONNECT1TO2);

      plan[0].pose.orientation = start.pose.orientation;
      plan[plan.size() - 1].pose.orientation = goal.pose.orientation;

      nav_msgs::Path path_pose;
      path_pose.header.frame_id = this->frame_id_;
      path_pose.header.stamp = ros::Time::now();
      path_pose.poses = plan;
      plan_pub_.publish(path_pose);
      return true;
    }

    // 第一棵树搜索到目标点
    if (pointCircleCollision(p_new.first, p_new.second, goal.pose.position.x,
                             goal.pose.position.y, goal_radius_)) {
      std::cout << "第一棵树搜索到目标点,耗时："
                << ros::Time::now().toSec() - start_time << "秒" << std::endl;

      getPathFromTree(nodes, nodes_2, nodes.back(), plan, GetPlanMode::TREE1);

      plan[0].pose.orientation = start.pose.orientation;
      plan[plan.size() - 1].pose.orientation = goal.pose.orientation;

      nav_msgs::Path path_pose;
      path_pose.header.frame_id = this->frame_id_;
      path_pose.header.stamp = ros::Time::now();
      path_pose.poses = plan;
      plan_pub_.publish(path_pose);
      return true;
    }

    // 第二棵树
    p_rand.first = p_new.first;
    p_rand.second = p_new.second;
    while (ros::ok()) {
      node_nearest =
          getNearest(nodes_2, p_rand);  // The nearest node of the random point
      p_new_2 = steer(node_nearest.x, node_nearest.y, p_rand.first,
                      p_rand.second);  // new point and node candidate.
      if (obstacleFree(node_nearest, p_new_2.first, p_new_2.second)) {
        Node newnode;
        newnode.x = p_new_2.first;
        newnode.y = p_new_2.second;
        newnode.node_id =
            nodes_2
                .size();  // index of the last element after the push_bask below
        newnode.parent_id = node_nearest.node_id;
        newnode.cost = 0.0;

        // Optimize
        newnode = chooseParent(node_nearest, newnode,
                               nodes_2);  // Select the best parent
        nodes_2.push_back(newnode);
        rewire(nodes_2, newnode);

        geometry_msgs::Point point_tem;
        point_tem.x = nodes_2[newnode.parent_id].x;
        point_tem.y = nodes_2[newnode.parent_id].y;
        point_tem.z = 0;
        this->marker_tree_2_.points.push_back(point_tem);

        point_tem.x = newnode.x;
        point_tem.y = newnode.y;
        point_tem.z = 0;
        this->marker_tree_2_.points.push_back(point_tem);

        if (nodes_2.size() % 10 == 0) {
          pubTreeMarker(this->marker_pub_, this->marker_tree_2_, 2);
        }

        if (this->isConnect(newnode, nodes, nodes_2, connect_node_on_tree1)) {
          is_connect_to_tree1 = true;
          ;
        }

        break;
      } else {
        srand(ros::Time::now().toNSec() + seed++);  //修改种子
        unsigned int rand_nu = rand() % 10;
        if (rand_nu > 1)  // 0.8的概率使用随机采样扩展
        {
          p_rand = sampleFree();  // random point in the free space
        } else                    // 0.2的概率使用启发扩展
        {
          p_rand.first = start.pose.position.x;
          p_rand.second = start.pose.position.y;
        }
      }
    }

    //两棵树连接在了一起，第二棵树搜索到了第一棵树上的节点
    if (is_connect_to_tree1) {
      std::cout << "两棵树连接在了一起 2->1 耗时："
                << ros::Time::now().toSec() - start_time << "秒" << std::endl;

      getPathFromTree(nodes, nodes_2, connect_node_on_tree1, plan,
                      GetPlanMode::CONNECT2TO1);

      plan[0].pose.orientation = start.pose.orientation;
      plan[plan.size() - 1].pose.orientation = goal.pose.orientation;

      nav_msgs::Path path_pose;
      path_pose.header.frame_id = this->frame_id_;
      path_pose.header.stamp = ros::Time::now();
      path_pose.poses = plan;
      plan_pub_.publish(path_pose);
      return true;
    }

    //第二棵树搜索到目标点
    if (pointCircleCollision(p_new_2.first, p_new_2.second,
                             start.pose.position.x, start.pose.position.y,
                             goal_radius_)) {
      std::cout << "第二棵树搜索到目标点,耗时："
                << ros::Time::now().toSec() - start_time << "秒" << std::endl;

      getPathFromTree(nodes, nodes_2, nodes.front(), plan, GetPlanMode::TREE2);

      plan[0].pose.orientation = start.pose.orientation;
      plan[plan.size() - 1].pose.orientation = goal.pose.orientation;

      nav_msgs::Path path_pose;
      path_pose.header.frame_id = this->frame_id_;
      path_pose.header.stamp = ros::Time::now();
      path_pose.poses = plan;
      plan_pub_.publish(path_pose);
      return true;
    }
  }
  ROS_WARN("failed to get a path.");
  return false;
}
};  // namespace APFstar_planner