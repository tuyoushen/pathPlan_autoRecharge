#ifndef APF_STAR_ROS_H
#define APF_STAR_ROS_H

#include <costmap_2d/costmap_2d.h>
#include <costmap_2d/costmap_2d_ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <nav_core/base_global_planner.h>
#include <nav_msgs/Path.h>
#include <ros/ros.h>
#include <visualization_msgs/Marker.h>

#include <cmath>
#include <vector>

struct Node {
  double x;
  double y;
  // int node_id;
  // int parent_id;
  double cost;

  bool operator==(const Node& node) {
    return (fabs(x - node.x) < 0.0001) && (fabs(y - node.y) < 0.0001) &&
           (fabs(cost - node.cost) < 0.0001);
  }

  bool operator!=(const Node& node) {
    if ((fabs(x - node.x) > 0.0001) || (fabs(y - node.y) > 0.0001) ||
        (fabs(cost - node.cost) > 0.0001))
      return true;
    else
      return false;
  }
};

enum GetPlanMode {
  POINT1 = 1,
  POINT2 = 2,
  CONNECT1TO2 = 3,
  CONNECT2TO1 = 4,
};

namespace APFstar_planner {
class APFstarPlannerROS : public nav_core::BaseGlobalPlanner {
 public:
  /**
   * @brief Default constructor of the plugin
   */
  APFstarPlannerROS();

  APFstarPlannerROS(std::string name, costmap_2d::Costmap2DROS* costmap_ros);

  ~APFstarPlannerROS();

  /**
   * @brief  Initialization function for the PlannerCore object
   * @param  name The name of this planner
   * @param  costmap_ros A pointer to the ROS wrapper of the costmap to use for
   * planning
   */
  void initialize(std::string name, costmap_2d::Costmap2DROS* costmap_ros);
  double inline normalizeAngle(double val, double min = -M_PI,
                               double max = M_PI);  //标准化角度
  void pubTreeMarker(ros::Publisher& marker_pub,
                     visualization_msgs::Marker marker, int id);  //路径可视化
  /**
   * @brief Given a goal pose in the world, compute a plan
   * @param start The start pose
   * @param goal The goal pose
   * @param plan The plan... filled by the planner
   * @return True if a valid plan was found, false otherwise
   */
  bool makePlan(const geometry_msgs::PoseStamped& start,
                const geometry_msgs::PoseStamped& goal,
                std::vector<geometry_msgs::PoseStamped>& plan);
  /*
   * @brief Compute the euclidean distance (straight-line distance) between two
   * points
   * @param px1 point 1 x
   * @param py1 point 1 y
   * @param px2 point 2 x
   * @param py2 point 2 y
   * @return the distance computed
   */

  bool collision(double x, double y);  //是否有障碍物
 protected:
  costmap_2d::Costmap2D* costmap_;
  costmap_2d::Costmap2DROS* costmap_ros_;
  std::string frame_id_;
  ros::Publisher plan_pub_;

 private:
  visualization_msgs::Marker marker_tree_;
  visualization_msgs::Marker marker_tree_2_;
  ros::Publisher marker_pub_;

  size_t max_nodes_num_;
  double plan_time_out_;
  double search_radius_;
  double goal_radius_;
  double epsilon_min_;
  double epsilon_max_;

  //路径优化参数
  double path_point_spacing_;
  double angle_difference_;

  double resolution_;
  bool initialized_;
};
}  // namespace APFstar_planner
#endif