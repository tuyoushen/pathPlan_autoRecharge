#include <actionlib/client/simple_action_client.h>
#include <cv_bridge/cv_bridge.h>
#include <geometry_msgs/Twist.h>
#include <image_transport/image_transport.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <ros/ros.h>
#include <signal.h>
#include <string.h>

#include <opencv2/highgui/highgui.hpp>
#include <sstream>  // for converting the command line parameter to integer

geometry_msgs::Twist vel_msg;

ros::Publisher cmdVel_Pub;              //定义速度发送器
image_transport::Subscriber image_Sub;  //定义图象接收器

void go_straight(geometry_msgs::Twist vel_msg, double area);
void turn_left(geometry_msgs::Twist vel_msg, double area);
void turn_right(geometry_msgs::Twist vel_msg, double area);
void imageCallback(const sensor_msgs::ImageConstPtr& msg);

typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction>
    MoveBaseClient;
struct goal_pose {
  double pose[3];
  double orientation[4];
};

int main(int argc, char* argv[]) {
  ros::init(argc, argv, "pub_node");
  setlocale(LC_ALL, "");
  ros::NodeHandle node;                      //定义ROS句柄
  image_transport::ImageTransport it(node);  //定义一个image_transport实例
  cmdVel_Pub = node.advertise<geometry_msgs::Twist>("/cmd_vel", 1);
  image_Sub = it.subscribe("/camera/image_raw", 1,
                           imageCallback);  //订阅话题“camera/image_raw”
  cmdVel_Pub = node.advertise<geometry_msgs::Twist>("/cmd_vel", 1);
  MoveBaseClient ac("move_base", true);
  while (!ac.waitForServer(ros::Duration(1.0))) {
    ROS_INFO("未初始化");
  }
  move_base_msgs::MoveBaseGoal goal;
  // goal.target_pose.header.frame_id="base_link"; //局部定位
  goal.target_pose.header.frame_id = "map";  //全局定位
  goal.target_pose.header.stamp = ros::Time::now();
  goal.target_pose.pose.position.x = 5.57;
  goal.target_pose.pose.position.y = 2.6;
  goal.target_pose.pose.position.z = 0;
  goal.target_pose.pose.orientation.x = 0;
  goal.target_pose.pose.orientation.y = 0;
  goal.target_pose.pose.orientation.z = 0.7;
  goal.target_pose.pose.orientation.w = 0.7;
  ac.sendGoal(goal);
  ROS_INFO("充电桩坐标 :(5.57,3.37)");
  ac.waitForResult();
  //已经到达充电桩附近
  if (ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED) {
    while (ros::ok()) {
      ros::spinOnce();  // 循环等待回调函数触发
    }
  }
  return 0;
}
//图象处理的主要函数
void image_process(cv::Mat img) {
  int th = 30;
  double cx, cy, area;
  cv::Mat img_rgb, img_out, img_threshold, img_canny;
  cv::Moments Mom;
  // opencv读取的bgr图像转换成rgb图象
  cv::cvtColor(img, img_rgb, cv::COLOR_BGR2RGB);
  std::vector<cv::Mat> rgbChannels(3);
  std::vector<std::vector<cv::Point>> contours;
  std::vector<cv::Vec4i> hierarchy;
  cv::split(img_rgb, rgbChannels);  //三通道分离
  cv::threshold(rgbChannels[0], img_threshold, th, 255, cv::THRESH_BINARY);
  cv::Canny(img_threshold, img_canny, 50, 150);
  cv::findContours(img_canny, contours, hierarchy, cv::RETR_EXTERNAL,
                   cv::CHAIN_APPROX_SIMPLE);
  for (int i = 0; i < contours.size(); i++) {
    // 计算面积
    area = -1 * cv::contourArea(contours[i], true);
    Mom = cv::moments(contours[i]);
    // 计算中心
    cx = Mom.m10 / Mom.m00;
    cy = Mom.m01 / Mom.m00;
    if (i > 10) break;
  }
  ROS_INFO("区域面积:%f,中心坐标:(%f,%f)", area, cx, cy);
  // cv::imshow("Input", img_rgb);
  // cv::imshow("Output", img_canny);
  // cv::waitKey(1);
  if (area > 420000) {
    cmdVel_Pub.publish(geometry_msgs::Twist());
    ros::shutdown();
  } else {
    if (cx > 645) {
      ROS_INFO("右转");
      turn_right(vel_msg, area);
    } else if (cx < 635) {
      ROS_INFO("左转");
      turn_left(vel_msg, area);
    } else {
      ROS_INFO("直行");
      go_straight(vel_msg, area);
    }
  }
}
void imageCallback(const sensor_msgs::ImageConstPtr& msg) {
  cv_bridge::CvImagePtr cv_ptr;  // 声明一个CvImage指针的实例
  try {
    cv_ptr = cv_bridge::toCvCopy(
        msg,
        sensor_msgs::image_encodings::
            RGB8);  //将ROS消息中的图象信息提取，生成新cv类型的图象，复制给CvImage指针
  } catch (cv_bridge::Exception& e)  //异常处理
  {
    ROS_ERROR("cv_bridge exception: %s", e.what());
    return;
  }
  image_process(cv_ptr->image);  //在CvImage指针的image中，将结果传送给处理函数
}
//直行
void go_straight(geometry_msgs::Twist vel_msg, double area) {
  cmdVel_Pub.publish(geometry_msgs::Twist());
  double vel_x = 0.1;
  if (area > 200000) {
    vel_msg.linear.x = vel_x * 0.8;
  } else {
    vel_msg.linear.x = vel_x;
  }
  cmdVel_Pub.publish(vel_msg);
  // 发送一个空的Twist消息让机器人停止移动
  vel_msg.linear.x = 0;
  ROS_INFO("直行");
}
//左转
void turn_left(geometry_msgs::Twist vel_msg, double area) {
  cmdVel_Pub.publish(geometry_msgs::Twist());
  double vel_z = 0.01;
  if (area < 1000) {
    vel_msg.angular.z = vel_z * 2;
  } else {
    vel_msg.angular.z = vel_z;
  }
  cmdVel_Pub.publish(vel_msg);
  // 发送一个空的Twist消息让机器人停止移动
  vel_msg.angular.z = 0;
  ROS_INFO("左转");
}
//右转
void turn_right(geometry_msgs::Twist vel_msg, double area) {
  cmdVel_Pub.publish(geometry_msgs::Twist());
  double vel_z = -0.01;
  if (area < 1000) {
    vel_msg.angular.z = vel_z * 2;
  } else {
    vel_msg.angular.z = vel_z;
  }
  cmdVel_Pub.publish(vel_msg);
  // 发送一个空的Twist消息让机器人停止移动
  vel_msg.angular.z = 0;
  ROS_INFO("右转");
}